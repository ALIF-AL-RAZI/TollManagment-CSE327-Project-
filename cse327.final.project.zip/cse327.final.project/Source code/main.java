package padma_bridge_toll;
import java.util.ArrayList;
import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
                
                
		
               

		/*int count=1;*/
		while (true) {

                        Toll_Plaza date_time = new Toll_Plaza();
                        date_time.Date();
                        date_time.Time();
                        User r1 = new User();
		        r1.checkUser();
                        int v=1;
                        /*int total_vehicle=count++;
                        System.out.println(total_vehicle);*/

                        Toll_Plaza count = new Toll_Plaza();
                        int c = count.vehicle_count(v);
                        System.out.println("\nToday Vehicle count: " + c+"\n");

                        
                    }

                    

                    /*System.out.println("Enter Vehicle Class:");
                
                int v_class = Non_Reg_Info.nextInt();
                
                Vehicle_Class payment = new Vehicle_Class();
                int pay = payment.payment(v_class);*/
		
      
       

	}

}